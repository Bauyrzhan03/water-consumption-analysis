# -*- coding: utf-8 -*-
"""
Анализ аномалий водопотребления.
Запуск: python analyze_water.py
Входные CSV должны лежать рядом со скриптом. Разделитель ;.
Выход: CSV-таблицы с найденными аномалиями и summary.txt.
"""
from pathlib import Path
import pandas as pd
import numpy as np

ROOT = Path(__file__).resolve().parent
p = pd.read_csv(ROOT / "pokazaniya.csv", sep=";", dtype={"anon_id": str})
pr = pd.read_csv(ROOT / "pribory.csv", sep=";", dtype={"anon_id": str})
ev = pd.read_csv(ROOT / "sobytiya.csv", sep=";", dtype={"anon_id": str})

p["data"] = pd.to_datetime(p["data"], errors="coerce")
p["pokazanie"] = pd.to_numeric(p["pokazanie"], errors="coerce")
p["paketov_za_sutki"] = pd.to_numeric(p["paketov_za_sutki"], errors="coerce")
p = p.dropna(subset=["anon_id", "data", "pokazanie"]).sort_values(["anon_id", "data"])
p["prev_date"] = p.groupby("anon_id")["data"].shift()
p["gap_days"] = (p["data"] - p["prev_date"]).dt.days
p["delta"] = p.groupby("anon_id")["pokazanie"].diff()
# Daily consumption is only inferred directly for adjacent calendar days.
p["daily"] = p["delta"].where(p["gap_days"].eq(1))
v = p[p["gap_days"].eq(1)].copy()

# 1. Negative readings: cumulative meter value decreased.
negative = v[v["daily"] < 0].copy()
negative[["anon_id","data","pokazanie","delta","daily","paketov_za_sutki"]].sort_values("daily").to_csv(
    ROOT/"negative_readings.csv", index=False, encoding="utf-8-sig")

# 2. Spikes: >=10 m3/day AND >=5x that device's median positive daily usage.
med = v[v["daily"] > 0].groupby("anon_id")["daily"].median()
v["device_median"] = v["anon_id"].map(med)
spikes = v[(v["daily"] >= 10) & (v["daily"] >= 5*v["device_median"])].copy()
spikes[["anon_id","data","daily","device_median","paketov_za_sutki"]].sort_values(
    "daily", ascending=False).to_csv(ROOT/"spikes.csv", index=False, encoding="utf-8-sig")

# 3. Physically implausible consumption: >=50 m3 in one day.
impossible = v[v["daily"] >= 50].copy()
impossible[["anon_id","data","daily","paketov_za_sutki"]].sort_values(
    "daily", ascending=False).to_csv(ROOT/"impossible.csv", index=False, encoding="utf-8-sig")

# 4/5. Long streaks on consecutive dates. Packet count >0 for zero-consumption streak.
def longest_streaks(frame, predicate, min_days=30):
    result = []
    for aid, g in frame.sort_values(["anon_id","data"]).groupby("anon_id"):
        g = g.reset_index(drop=True)
        flags = predicate(g).fillna(False).to_numpy()
        dates = g["data"].to_numpy()
        best = current = 0
        best_start = best_end = None
        current_start = None
        for i, flag in enumerate(flags):
            contiguous = i > 0 and (dates[i]-dates[i-1]).astype("timedelta64[D]").astype(int) == 1
            if flag:
                if current == 0 or not contiguous:
                    current = 1
                    current_start = dates[i]
                else:
                    current += 1
                if current > best:
                    best, best_start, best_end = current, current_start, dates[i]
            else:
                current = 0
        if best >= min_days:
            result.append((aid, best, str(best_start)[:10], str(best_end)[:10]))
    return pd.DataFrame(result, columns=["anon_id","streak_days","start","end"])

positive_streak = longest_streaks(v, lambda g: g["daily"] > 0)
zero_streak = longest_streaks(v, lambda g: (g["daily"] == 0) & (g["paketov_za_sutki"] > 0))
positive_streak.sort_values("streak_days", ascending=False).to_csv(
    ROOT/"continuous_positive_30d.csv", index=False, encoding="utf-8-sig")
zero_streak.sort_values("streak_days", ascending=False).to_csv(
    ROOT/"zero_30d_packets.csv", index=False, encoding="utf-8-sig")

# 6. Structural shift: median daily consumption in second half >=3x first half,
# or falls to <=1/3. Require >=30 valid daily observations in each half.
v["half"] = np.where(v["data"] < pd.Timestamp("2026-04-01"), "first", "second")
medians = v.groupby(["anon_id","half"])["daily"].median().unstack()
counts = v.groupby(["anon_id","half"])["daily"].count().unstack()
eligible = medians.index[(counts.get("first", pd.Series(dtype=float)) >= 30) &
                         (counts.get("second", pd.Series(dtype=float)) >= 30)]
medians = medians.loc[eligible].dropna(subset=["first","second"])
up = medians[(medians["first"] > 0) & (medians["second"] >= 3*medians["first"])].copy()
down = medians[(medians["first"] >= 0.05) & (medians["second"] <= medians["first"]/3)].copy()
up_out = up.copy()
up_out["ratio_second_vs_first"] = up_out["second"]/up_out["first"]
up_out.reset_index().rename(columns={"index":"anon_id"}).to_csv(
    ROOT/"step_up_3x.csv", index=False, encoding="utf-8-sig")
down.reset_index().rename(columns={"index":"anon_id","first":"median_first","second":"median_second"}).to_csv(
    ROOT/"step_down_3x.csv", index=False, encoding="utf-8-sig")

# 7. Event comparison: negative readings on same day or within +/-3 days of a magnet event.
ev["data"] = pd.to_datetime(ev["data"], errors="coerce")
magnets = ev[ev["sobytie"].astype(str).str.lower().str.contains("магнит", na=False)]
magnet_keys = set(zip(magnets["anon_id"], magnets["data"]))
negative["magnet_same_day"] = [(aid, d) in magnet_keys for aid,d in zip(negative["anon_id"], negative["data"])]
negative["magnet_within_3_days"] = [
    any((aid, d + pd.Timedelta(days=k)) in magnet_keys for k in range(-3,4))
    for aid,d in zip(negative["anon_id"], negative["data"])
]
negative.to_csv(ROOT/"negative_event_match.csv", index=False, encoding="utf-8-sig")

summary = f"""ИТОГИ АНАЛИЗА
Показаний: {len(p):,}; приборов в показаниях: {p.anon_id.nunique():,}.
Период: {p.data.min().date()} — {p.data.max().date()}.
Расход вычислялся как разность текущего и предыдущего накопительного показания только при наличии соседних календарных дней.
Отрицательные значения: {len(negative):,} суточных записей, {negative.anon_id.nunique():,} приборов.
Всплески (>=10 м³/сутки и >=5x личной медианы положительного расхода): {len(spikes):,} записей, {spikes.anon_id.nunique():,} приборов.
Физически неправдоподобный расход (>=50 м³/сутки): {len(impossible):,} записей, {impossible.anon_id.nunique():,} приборов.
Положительный расход без нулевых суток >=30 дней подряд: {len(positive_streak):,} приборов.
Нулевой расход >=30 дней подряд при пакетах >0: {len(zero_streak):,} приборов.
Ступенька вверх (медиана после 2026-04-01 >=3x медианы до даты, минимум 30 наблюдений в каждой половине): {len(up):,} приборов.
Ступенька вниз (первая медиана >=0.05, вторая <=1/3 первой, минимум 30 наблюдений в каждой половине): {len(down):,} приборов.
Отрицательные записи с событием «магнит» в тот же день: {int(negative.magnet_same_day.sum())} ({negative.magnet_same_day.mean():.2%}).
Отрицательные записи в пределах +/-3 дней от «магнит»: {int(negative.magnet_within_3_days.sum())} ({negative.magnet_within_3_days.mean():.2%}).

Пороговые значения — аналитические эвристики для первичного отбора, а не доказательство неисправности/вмешательства.
"""
(ROOT/"summary.txt").write_text(summary, encoding="utf-8")
print(summary)
